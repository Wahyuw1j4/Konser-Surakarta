<?php $__env->startSection('content'); ?>
<main>
  <div class="p-4 ">
    <form action="">
      <?php echo csrf_field(); ?>

    </form>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('component.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\UJK Laravel Tiket Konser\resources\views/tambah.blade.php ENDPATH**/ ?>