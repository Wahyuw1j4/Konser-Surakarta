<?php $__env->startSection('content'); ?>
<main>
  <div class="p-4 lg:px-[12rem]">
    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
      <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
        <tr>
          <th scope="col" class="px-6 py-3">Id Konser</th>
          <th scope="col" class="px-6 py-3">Username</th>
          <th scope="col" class="px-6 py-3">Jumlah tiket</th>
          <th scope="col" class="px-6 py-3">Total Harga</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $tikets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tiket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="bg-white dark:bg-gray-800 text-center">
          <td><?php echo e($tiket->id_konser); ?></td>
          <td><?php echo e($tiket->username); ?></td>
          <td><?php echo e($tiket->jumlah_tiket); ?></td>
          <td><?php echo e($tiket->total_harga); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
 
        
 
    
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\UJK Laravel Tiket Konser\resources\views/listTiket.blade.php ENDPATH**/ ?>