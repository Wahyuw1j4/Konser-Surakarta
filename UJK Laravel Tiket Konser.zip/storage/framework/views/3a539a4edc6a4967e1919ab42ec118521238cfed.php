<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
  <header>
    <div class="flex justify-between items-center border-b-2 p-4 lg:px-[12rem]">
      <div class="">
        <h1 class="text-1xl font-bold">Surakarta Konser</h1>
      </div>
      <div class="">
        <a href="" class="p-2 rounded-lg hover:underline">Logout</a>
      </div>
    </div>
</header>
<?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH D:\Project\UJK Laravel Tiket Konser\resources\views/component/navbar.blade.php ENDPATH**/ ?>