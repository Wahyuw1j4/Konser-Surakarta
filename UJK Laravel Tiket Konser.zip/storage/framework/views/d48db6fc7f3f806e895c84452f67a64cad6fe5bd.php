<?php $__env->startSection('content'); ?>
<main>
  <div class="p-4 lg:px-[12rem]">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
    <a href="<?php echo e(route('tambah')); ?>"class="flex border-2 p-2 mb-2 w-[5rem] rounded-lg " >Tambah</a>
    <?php endif; ?>
    <div class="grid grid-cols-2 gap-2">
    <?php $__currentLoopData = $konsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $konser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo e(route('konser', ['id' => $konser['id']])); ?>">
        <div class="border-2 h-[250px] rounded-lg shadow-md">
          <div class="border-b-2 h-[170px] flex justify-center">
            <img class="h-20" src="<?php echo e(asset('storage\images/' . $konser->poster)); ?>" alt="image description" style="width:15rem; height:170px">
        </div>
          <div class="px-2">
              <h3 class="text-1xl font-bold"><?php echo e($konser['nama']); ?></h3>
              <p class="text-2md text-right  mt-2">Selebihnya...</p>
          </div>
        </div>
      </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\UJK Laravel Tiket Konser\resources\views/index.blade.php ENDPATH**/ ?>