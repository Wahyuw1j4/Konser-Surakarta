<?php $__env->startSection('content'); ?>
<main>
  <div class="p-4 ">
    <button href=""class="flex border-2 p-2 mb-2 w-[5rem] rounded-lg" >Tambah</button>
    <div class="grid grid-cols-2 gap-2">
      <div class="border-2 h-[250px] rounded-lg shadow-md">
        <div class="border-b-2 h-[170px]">
      </div>
        <div class="px-2">
            <h3 class="text-1xl font-bold">Pesta Rakyat</h3>
            <p class="text-2md text-right  mt-2">Selebihnya...</p>
        </div>
      </div>
    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('component.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\UJK Laravel Tiket Konser\resources\views/welcome.blade.php ENDPATH**/ ?>